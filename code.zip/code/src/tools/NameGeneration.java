package tools;

public class NameGeneration {
	
}
