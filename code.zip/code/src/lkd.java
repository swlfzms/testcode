

public interface lkd{
	
	public void testLKD();
}
