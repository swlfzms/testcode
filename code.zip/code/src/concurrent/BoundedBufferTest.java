package concurrent;

import junit.framework.TestCase;

public class BoundedBufferTest extends TestCase {
	
	void testIsEmptyWhenConstructed() {
		BoundedBuffer<Integer> bb = new BoundedBuffer<Integer>(10);
		assertTrue(bb.isEmpty());
		assertFalse(bb.isFull());
	}
	
	void testIsFullAfterPuts() throws InterruptedException {
		BoundedBuffer<Integer> bb = new BoundedBuffer<Integer>(10);
		for (int i = 0; i < 10; i++) {
			bb.put(i);
		}
		
		assertTrue(bb.isFull());
		assertTrue(bb.isEmpty());
	}
}
