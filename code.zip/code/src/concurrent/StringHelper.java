package concurrent;

public class StringHelper {

	private String str;
	
	public StringHelper(String str) {
		// TODO Auto-generated constructor stub
		this.str = str;
	}
	
	public void setStr(String str){
		this.str =str;
	}
	
	public String getStr(){
		return this.str;
	}
	
	public String toString(){
		return this.str;
	}
}
