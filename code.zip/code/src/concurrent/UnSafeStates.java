package concurrent;

public class UnSafeStates {

	
	private String[] states = new String[]{
		"ak","al","am"	
	};
	
	public String[] getStates(){
		return states;
	}
}
