
public class Image {
	
	public static void main(String[] args){
		
	}
}
